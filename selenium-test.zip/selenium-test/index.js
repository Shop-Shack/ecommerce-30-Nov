require('chromedriver');
const {Builder, By, Key, util} = require("selenium-webdriver");

async function example(){
    let driver = await new Builder().forBrowser("chrome").build();
    // await driver.get("http://www.google.com");
    // await driver.get("http://localhost:3000/register");
    // // await driver.findElement(By.name('q')).sendKeys('Selenium', Key.RETURN);
    // await driver.findElement(By.name('reg_name')).sendKeys('Srushti', Key.RETURN);
    // await driver.findElement(By.name('reg_email')).sendKeys('srushant23324@gmail.com', Key.RETURN);
    // await driver.findElement(By.name('reg_pass')).sendKeys('123', Key.RETURN);
    // await driver.findElement(By.name('reg_pass_conf')).sendKeys('123', Key.RETURN);
    
    // await driver.get("http://localhost:3000/login");
    // await driver.findElement(By.name('log_email')).sendKeys('srushant23324@gmail.com', Key.RETURN);
    // await driver.findElement(By.name('log_pass')).sendKeys('123', Key.RETURN);

    await driver.get("http://localhost:3000/");
    // shopNowText
    
    driver.findElement(By.id('shopNowText')).click();
    
    await driver.get("http://localhost:3000/shop");

    const arr = await driver.findElements(By.css("a"));

    console.log(arr);
   

    // await driver.findElement(By.id('women-card'));
    

    // await driver.get("http://localhost:3000/women");
    
    // driver.findElement(By.linkText('Women')).click();
    // driver.findElement(By.cssSelector("div[name='women-card']")).click();
    // driver.findElement(By.id("kids-card")).click();
    

}

example();